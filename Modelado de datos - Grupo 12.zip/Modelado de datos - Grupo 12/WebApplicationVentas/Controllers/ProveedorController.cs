﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelado_de_datos___Grupo_12.Entidades;
using Modelado_de_datos___Grupo_12.Repositorio;

namespace WebApplicationVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProveedorController : ControllerBase
    {
        private readonly IRepositorioProveedores _repositorioUsuario;
        public ProveedorController(IRepositorioProveedores usuario)
        {
            this._repositorioUsuario = usuario;
        }


        //AGREGAR
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Proveedor usuario)
        {
            try
            {
                await _repositorioUsuario.AgregarProveedor(usuario);
                return CreatedAtAction("Get", new { id = usuario.ProveedorId }, usuario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        //CONSULTAR
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioUsuario.ObtenerProveedor();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var usuario = await _repositorioUsuario.ObtenerProveedorID(id);
                return Ok(usuario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioUsuario.EliminarProveedor(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Proveedor usuario)
        {
            try
            {
                await _repositorioUsuario.ModificarProveedor(usuario);
                return Ok(usuario.ProveedorId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }



    }
}

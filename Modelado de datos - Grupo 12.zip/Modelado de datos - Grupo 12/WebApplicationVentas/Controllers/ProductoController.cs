﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelado_de_datos___Grupo_12.Entidades;
using Modelado_de_datos___Grupo_12.Repositorio;

namespace WebApplicationVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly IRepositorioProductos _repositorioUsuario;
        public ProductoController(IRepositorioProductos usuario)
        {
            this._repositorioUsuario = usuario;
        }


        //AGREGAR
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Producto usuario)
        {
            try
            {
                await _repositorioUsuario.AgregarProducto(usuario);
                return CreatedAtAction("Get", new { id = usuario.ProductoId }, usuario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        //CONSULTAR
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioUsuario.ObtenerProducto();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

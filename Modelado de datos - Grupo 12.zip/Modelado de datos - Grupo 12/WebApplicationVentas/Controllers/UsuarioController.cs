﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelado_de_datos___Grupo_12.Entidades;
using Modelado_de_datos___Grupo_12.Repositorio;

namespace WebApplicationVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        private readonly IRepositorioUsuario _repositorioUsuario;
        public UsuarioController(IRepositorioUsuario usuario)
        {
            this._repositorioUsuario = usuario;
        }

        [HttpGet("byCorreo/{correo}/{contrasenia}")]

        public async Task<IActionResult> GetUsuarioByCorreo(string correo, string contrasenia)
        {
            try
            {
                var usuario = await _repositorioUsuario.GetUsuarioByCorreo(correo, contrasenia);
                if (usuario != null)
                {
                    return Ok(usuario);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //AGREGAR
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Usuario usuario)
        {
            try
            {
                await _repositorioUsuario.AgregarUsuario(usuario);
                return CreatedAtAction("Get", new { id = usuario.UsuarioId }, usuario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        //CONSULTAR
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioUsuario.ObtenerUsuario();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var usuario = await _repositorioUsuario.ObtenerUsuarioID(id);
                return Ok(usuario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioUsuario.EliminarUsuario(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Usuario usuario)
        {
            try
            {
                await _repositorioUsuario.ModificarUsuario(usuario);
                return Ok(usuario.UsuarioId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }





    }
}

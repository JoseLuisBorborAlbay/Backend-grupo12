﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Modelado_de_datos___Grupo_12.Entidades;
using Modelado_de_datos___Grupo_12.Repositorio;

namespace WebApplicationVentas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdenCompraController : ControllerBase
    {

        private readonly IRepositorioOrdencompras _repositorioUsuario;
        public OrdenCompraController(IRepositorioOrdencompras usuario)
        {
            this._repositorioUsuario = usuario;
        }


        //AGREGAR
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] OrdenCompra usuario)
        {
            try
            {
                await _repositorioUsuario.AgregarOrdencompra(usuario);
                return CreatedAtAction("Get", new { id = usuario.OrdenCompraId }, usuario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        //CONSULTAR
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioUsuario.ObtenerOrdencompra();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}


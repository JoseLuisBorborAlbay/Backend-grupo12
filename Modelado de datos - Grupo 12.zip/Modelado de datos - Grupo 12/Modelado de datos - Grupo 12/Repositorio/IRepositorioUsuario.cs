﻿using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public interface IRepositorioUsuario
    {
        Task<List<Usuario>> ObtenerUsuario();
        Task<Usuario?> ObtenerUsuarioID(int id);
        Task<int> AgregarUsuario(Usuario usuario);
        Task<int> ModificarUsuario(Usuario usuario);
        Task EliminarUsuario(int id);
        Task<Usuario> GetUsuarioByCorreo(string correo, string contrasenia);
    }
}
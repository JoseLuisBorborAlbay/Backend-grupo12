﻿using Microsoft.EntityFrameworkCore;
using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public class RepositorioRevistas : IRepositorioRevistas
    {
        private readonly ConexionDB context;
        public RepositorioRevistas(ConexionDB context)
        {
            this.context = context;
        }

        public async Task<int> AgregarRevista(Revista revista)
        {
            context.Add(revista);
            await context.SaveChangesAsync();
            return revista.RevistaId;
        }

        public async Task EliminarRevista(int id)
        {
            Revista revista = await context.Revistas.FindAsync(id);
            context.Revistas.Remove(revista);
            context.SaveChanges();
        }

        public async Task<int> ModificarRevista(Revista revista)
        {
            Revista objRevista = await context.Revistas.FindAsync(revista.RevistaId);
            objRevista.RevistaId = revista.RevistaId;
            objRevista.imagenRevista = revista.imagenRevista;
            objRevista.titulo = revista.titulo;
            objRevista.descripcion = revista.descripcion;
           
            await context.SaveChangesAsync();
            return objRevista.RevistaId;
        }

        public async Task<List<Revista>> ObtenerRevista()
        {
            return await context.Revistas.ToListAsync();
        }

        public async Task<Revista?> ObtenerRevistaID(int id)
        {
            return await context.Revistas.FindAsync(id);
        }
    }
}

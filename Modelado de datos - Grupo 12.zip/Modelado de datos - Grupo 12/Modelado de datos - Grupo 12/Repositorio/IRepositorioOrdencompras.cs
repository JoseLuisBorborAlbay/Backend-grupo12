﻿using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public interface IRepositorioOrdencompras
    {
        Task<List<OrdenCompra>> ObtenerOrdencompra();
        Task<OrdenCompra?> ObtenerOrdenID(int id);
        Task<int> AgregarOrdencompra(OrdenCompra ordenCompra);
        Task<int> ModificarOrdencompra(OrdenCompra ordencompra); 
        Task EliminarOrdencompra(int id);
    }
}

﻿using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public interface IRepositorioProveedores
    {
        Task<List<Proveedor>> ObtenerProveedor();
        Task<Proveedor?> ObtenerProveedorID(int id);
        Task<int> AgregarProveedor(Proveedor proveedor);
        Task<int> ModificarProveedor(Proveedor proveedor);
        Task EliminarProveedor(int id);
    }
}

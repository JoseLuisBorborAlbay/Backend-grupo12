﻿using Microsoft.EntityFrameworkCore;
using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public class RepositorioProductos : IRepositorioProductos
    {
        private readonly ConexionDB context;
        public RepositorioProductos(ConexionDB context)
        {
            this.context = context;
        }

        public async Task<int> AgregarProducto(Producto producto)
        {
            context.Add(producto);
            await context.SaveChangesAsync();
            return producto.ProductoId;
        }

        public async Task EliminarProducto(int id)
        {
            Producto producto = await context.Productos.FindAsync(id);
            context.Productos.Remove(producto);
            context.SaveChanges();
        }

        public async Task<int> ModificarProducto(Producto producto)
        {
            Producto objProducto = await context.Productos.FindAsync(producto.ProductoId);
            objProducto.ProductoId = producto.ProductoId;
            objProducto.ProveedorId = producto.ProveedorId;
            objProducto.nombre = producto.nombre;
            objProducto.descripcion = producto.descripcion;
            objProducto.cantidad = producto.cantidad;
            objProducto.precio = producto.precio;
            await context.SaveChangesAsync();
            return objProducto.ProductoId;
        }

        public async Task<List<Producto>> ObtenerProducto()
        {
            return await context.Productos.ToListAsync();
        }

        public async Task<Producto?> ObtenerProductoID(int id)
        {
            return await context.Productos.FindAsync(id);
        }
    }
}

﻿using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public interface IRepositorioProductos
    {
        Task<List<Producto>> ObtenerProducto();
        Task<Producto?> ObtenerProductoID(int id);
        Task<int> AgregarProducto(Producto producto);
        Task<int> ModificarProducto(Producto producto);
        Task EliminarProducto(int id);
    }
} 


﻿using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public interface IRepositorioCompras
    {
        Task<List<Compra>> ObtenerCompra();
        Task<Compra?> ObtenerCompraID(int id);
        Task<int> AgregarCompra(Compra compra);
        Task<int> ModificarCompra(Compra compra);
        Task EliminarCompra(int id);

    }
}

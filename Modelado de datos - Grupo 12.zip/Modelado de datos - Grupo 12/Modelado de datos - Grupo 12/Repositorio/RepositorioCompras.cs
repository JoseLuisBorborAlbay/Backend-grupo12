﻿using Microsoft.EntityFrameworkCore;
using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio 
{
    public class RepositorioCompras : IRepositorioCompras
    {
        private readonly ConexionDB context;
        public RepositorioCompras(ConexionDB context)
        {
            this.context = context;
        }

        public async Task<int> AgregarCompra(Compra compra)
        {
            context.Add(compra);
            await context.SaveChangesAsync();
            return compra.CompraId;
        }

        public async Task EliminarCompra(int id)
        {
            Compra compra = await context.Compras.FindAsync(id);
            context.Compras.Remove(compra);
            context.SaveChanges();
        }

        public async Task<int> ModificarCompra(Compra compra)
        {
            Compra objCompra = await context.Compras.FindAsync(compra.CompraId);
            objCompra.CompraId = compra.CompraId;
            objCompra.ProductoId = compra.ProductoId;
            await context.SaveChangesAsync();
            return objCompra.CompraId;
        }

        public async Task<List<Compra>> ObtenerCompra()
        {
            return await context.Compras.ToListAsync(); 
        }

        public async Task<Compra?> ObtenerCompraID(int id)
        {
            return await context.Compras.FindAsync(id);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public class RepositorioUsuario : IRepositorioUsuario
    {
        private readonly ConexionDB context;
        public RepositorioUsuario(ConexionDB context)
        {
            this.context = context;
        }

        public async Task<int> AgregarUsuario(Usuario usuario)
        {
            context.Add(usuario);
            await context.SaveChangesAsync();
            return usuario.UsuarioId;
        }

        public async Task EliminarUsuario(int id)
        {
            Usuario usuario = await context.Usuarios.FindAsync(id);
            context.Usuarios.Remove(usuario);
            context.SaveChanges();
        }

        public async Task<Usuario> GetUsuarioByCorreo(string correo, string contrasenia)
        {
          
                return await context.Usuarios
                .Where(u => u.correo == correo && u.contrasenia == contrasenia)
                .FirstOrDefaultAsync();

        }

        public async Task<int> ModificarUsuario(Usuario usuario)
        {
            Usuario objUsuario = await context.Usuarios.FindAsync(usuario.UsuarioId);
            objUsuario.UsuarioId = usuario.UsuarioId;
            objUsuario.nombre = usuario.nombre;
            objUsuario.correo = usuario.correo;
            objUsuario.contrasenia = usuario.contrasenia;
            objUsuario.direccion = usuario.direccion;

            await context.SaveChangesAsync();
            return objUsuario.UsuarioId;
        }

        public async Task<List<Usuario>> ObtenerUsuario()
        {
            return await context.Usuarios.ToListAsync();
        }

        public async Task<Usuario?> ObtenerUsuarioID(int id)
        {
            return await context.Usuarios.FindAsync(id);
        }
    }
}

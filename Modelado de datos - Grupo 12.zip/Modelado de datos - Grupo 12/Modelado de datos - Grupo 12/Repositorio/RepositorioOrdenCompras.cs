﻿using Microsoft.EntityFrameworkCore;
using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public class RepositorioOrdenCompras : IRepositorioOrdencompras
    {
        private readonly ConexionDB context;
        public RepositorioOrdenCompras(ConexionDB context)
        {
            this.context = context;
        }

        public async Task<int> AgregarOrdencompra(OrdenCompra ordenCompra)
        {
            context.Add(ordenCompra);
            await context.SaveChangesAsync();
            return ordenCompra.OrdenCompraId;
        }

        public async Task EliminarOrdencompra(int id)
        {
            OrdenCompra ordenCompra = await context.OrdenCompras.FindAsync(id);
            context.OrdenCompras.Remove(ordenCompra);
            context.SaveChanges();
        }

        public async Task<int> ModificarOrdencompra(OrdenCompra ordencompra)
        {
            OrdenCompra objOrden = await context.OrdenCompras.FindAsync(ordencompra.OrdenCompraId);
            objOrden.OrdenCompraId = ordencompra.OrdenCompraId;
            objOrden.ProductoId = ordencompra.ProductoId;
            objOrden.UsuarioId = ordencompra.UsuarioId;
            objOrden.fecha = ordencompra.fecha;
            await context.SaveChangesAsync(); 
            return objOrden.OrdenCompraId;
        }

        public async Task<List<OrdenCompra>> ObtenerOrdencompra()
        {
            return await context.OrdenCompras.ToListAsync();
        }

        public async Task<OrdenCompra?> ObtenerOrdenID(int id)
        {
            return await context.OrdenCompras.FindAsync(id);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public class RepositorioProveedores : IRepositorioProveedores
    {
        private readonly ConexionDB context;
        public RepositorioProveedores(ConexionDB context)
        {
            this.context = context;
        }
        
        public async Task<int> AgregarProveedor(Proveedor proveedor)
        {
            context.Add(proveedor);
            await context.SaveChangesAsync();
            return proveedor.ProveedorId;
        }

        public async Task EliminarProveedor(int id)
        {
            Proveedor proveedor = await context.Proveedores.FindAsync(id);
            context.Proveedores.Remove(proveedor);
            context.SaveChanges();
        }
        
        public async Task<int> ModificarProveedor(Proveedor proveedor)
        {
            Proveedor objProveedor = await context.Proveedores.FindAsync(proveedor.ProveedorId);
            objProveedor.ProveedorId = proveedor.ProveedorId;
            objProveedor.nombre = proveedor.nombre;
            objProveedor.direccion = proveedor.direccion;
            objProveedor.telefono = proveedor.telefono;
            objProveedor.correo = proveedor.correo;
            await context.SaveChangesAsync();
            return objProveedor.ProveedorId;
        }

        public async Task<List<Proveedor>> ObtenerProveedor()
        {
            return await context.Proveedores.ToListAsync();
        }

        public async Task<Proveedor?> ObtenerProveedorID(int id)
        {
            return await context.Proveedores.FindAsync(id);
        }
    }
}

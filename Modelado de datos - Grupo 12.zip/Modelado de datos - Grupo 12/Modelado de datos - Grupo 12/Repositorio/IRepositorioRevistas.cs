﻿using Modelado_de_datos___Grupo_12.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Repositorio
{
    public interface IRepositorioRevistas
    {
        Task<List<Revista>> ObtenerRevista();
        Task<Revista?> ObtenerRevistaID(int id);
        Task<int> AgregarRevista(Revista revista);
        Task<int> ModificarRevista(Revista revista);
        Task EliminarRevista(int id);
    }
}
﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Modelado_de_datos___Grupo_12.Migrations
{
    /// <inheritdoc />
    public partial class proceso : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

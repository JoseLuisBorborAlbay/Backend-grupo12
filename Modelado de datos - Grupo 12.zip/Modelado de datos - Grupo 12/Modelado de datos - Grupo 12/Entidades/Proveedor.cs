﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Entidades
{
    public class Proveedor
    {
        public int ProveedorId { get; set; }
        public string nombre { get; set; } = string.Empty;
        public string direccion { get; set; } = string.Empty;
        public string telefono  { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;

    }
}

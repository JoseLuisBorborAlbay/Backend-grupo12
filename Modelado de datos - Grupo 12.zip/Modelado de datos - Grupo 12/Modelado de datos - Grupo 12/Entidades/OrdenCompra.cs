﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Entidades
{
    public class OrdenCompra
    {
        public int OrdenCompraId { get; set; }
        public int ProductoId { get; set; }
        public int UsuarioId { get; set; }
        public Producto? Producto { get; set; } 
        public Usuario? Usuario { get; set; }
        public DateTime fecha { get; set; }
        public int total { get; set; }
        public int subtotal { get; set; }
        public int totalApagar { get; set; }

    }
}

﻿using Microsoft.EntityFrameworkCore;

namespace Modelado_de_datos___Grupo_12.Entidades
{
    public class ConexionDB : DbContext
    {
         public ConexionDB(DbContextOptions options) : base(options) {}


        /*protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=localhost\SQLEXPRESS;Database=VentasMilitarGrupo12;Integrated Security=True;TrustServerCertificate=True;");
            // SE UTILIZA localhost YA QUE EL NOMBRE DEL SERVIDOR ES José_Borbor\SQLEXPRESS Y NO LO RECONOCE POR TENER UN CARACTER ESPECIAL
        }*/

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Compra> Compras { get; set; }
        public DbSet<OrdenCompra> OrdenCompras { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Proveedor> Proveedores { get; set; }
        public DbSet<Revista> Revistas { get; set; }
    }
}


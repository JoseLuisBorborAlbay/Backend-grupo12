﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Entidades
{
    public class Compra
    {
        public int CompraId { get; set; }
        public int ProductoId { get; set; }
        public Producto? Producto { get; set; }
    }
}


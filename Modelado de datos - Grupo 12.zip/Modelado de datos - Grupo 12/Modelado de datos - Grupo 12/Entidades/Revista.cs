﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelado_de_datos___Grupo_12.Entidades
{
    public class Revista
    {
        public int RevistaId { get; set; }
        public byte[] imagenRevista { get; set; }
        public string titulo { get; set; } = string.Empty;
        public string descripcion { get; set; } = string.Empty;
    }
}

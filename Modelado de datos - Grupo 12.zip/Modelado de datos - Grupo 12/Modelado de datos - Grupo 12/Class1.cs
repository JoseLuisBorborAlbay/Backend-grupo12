﻿namespace Modelado_de_datos___Grupo_12
{
    public class Class1
    {

    }
}
